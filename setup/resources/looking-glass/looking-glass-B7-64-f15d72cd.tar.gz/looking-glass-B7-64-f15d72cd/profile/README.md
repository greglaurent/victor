##This directory contains programs for LG performance profiling.

###Directories:

* `client` - dummy client that profiles the host application's performance.
