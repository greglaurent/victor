
To build use `cmake path_to_example_glfw_opengl3` and then `make install`

`STATIC_BUILD` is a cmake variable if you want to do static linking.