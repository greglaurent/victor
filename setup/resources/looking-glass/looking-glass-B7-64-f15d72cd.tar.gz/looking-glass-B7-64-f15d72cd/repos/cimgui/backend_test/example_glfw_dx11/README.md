
This example needs dx11 in generation before compile. (add dx11 to generator.bat(sh) and generate)

`STATIC_BUILD` is the cmake variable to do static linking

Only tested with VC nmake.