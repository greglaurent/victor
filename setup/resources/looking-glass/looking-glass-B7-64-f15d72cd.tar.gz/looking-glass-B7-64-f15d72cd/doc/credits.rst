.. _looking_glass_team:

Looking Glass team
##################

A list of the wonderful people who make this possible.

.. _lg_devs:

Developers
------------------

* gnif (Geoffrey McRae)
* quantum (Guanzhong Chen)
* xyene (Tudor Brindus)
* spencercw (Chris Spencer)

.. _lg_documentation_guys:

Documentation
-------------

* JJRcop (Jonathan Rubenstein)
